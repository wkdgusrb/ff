# Sheriff Robot — Face Tracking System

브라우저에서 실행되는 실시간 얼굴 인식 데모입니다. 웹캠을 통해 얼굴 랜드마크를 추적하고, 얼굴 중심 좌표와 대략적인 얼굴 회전 방향을 화면에 표시합니다.

## 주요 기능

- 실시간 얼굴 랜드마크 인식
- 얼굴 중심의 X/Y 픽셀 좌표 표시
- 고개 방향(Pitch / Yaw / Roll) 추정
- 얼굴이 영상 너비의 35%를 넘으면 근접 경고 표시
- 브라우저 안에서 처리하는 카메라 영상

## 실행하기

### 방법 1: GitHub Pages로 공개하기

1. GitHub에서 새 저장소(repository)를 만듭니다.
2. 이 폴더의 파일을 저장소 최상위(root)에 업로드합니다.
3. 저장소의 **Settings → Pages**로 이동합니다.
4. **Deploy from a branch**를 선택합니다.
5. Branch는 `main`, 폴더는 `/(root)`로 선택하고 저장합니다.
6. 게시가 완료되면 표시된 GitHub Pages 주소를 엽니다.
7. **카메라 시작**을 누르고 브라우저 카메라 권한을 허용합니다.

### 방법 2: VS Code에서 로컬 실행

1. 폴더를 VS Code로 엽니다.
2. VS Code 확장 프로그램에서 **Live Server**를 설치합니다.
3. `index.html`을 마우스 오른쪽 버튼으로 클릭하고 **Open with Live Server**를 선택합니다.
4. 브라우저에서 **카메라 시작**을 누릅니다.

## 참고 사항

- 카메라 접근은 `localhost` 또는 HTTPS 환경에서 사용하는 것이 좋습니다. GitHub Pages는 HTTPS를 제공합니다.
- 인터넷 연결이 필요합니다. MediaPipe 라이브러리와 얼굴 인식 모델은 CDN에서 불러옵니다.
- 회전 각도는 추정값이며, 기기와 카메라 방향에 따라 보정이 필요할 수 있습니다.
- 근접 경고는 실제 거리 측정이 아닙니다. 화면에서 얼굴이 차지하는 비율을 기준으로 합니다.
- 영상은 이 프로젝트의 코드에서 서버로 업로드하지 않고 브라우저 안에서 처리합니다.
- 이 프로젝트는 데모이며, 전문적인 안전 감시 용도로 설계되지 않았습니다.

## 기술

- HTML / CSS / JavaScript
- MediaPipe Tasks Vision Face Landmarker

## License

MIT 라이선스를 사용하려면 프로젝트를 공개하기 전에 `LICENSE` 파일을 확인하고 필요한 저작권 정보를 유지하세요.
